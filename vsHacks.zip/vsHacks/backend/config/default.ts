export default {
    corsOrigin: 'http://localhost:3000',
    port: 4000,
    host: 'localhost',
}