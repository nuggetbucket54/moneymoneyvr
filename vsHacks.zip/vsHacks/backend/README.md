# backend
Backend built with MongoDB, Node.JS

# Installation
## Development
- Install all required libraries by running `npm install -D`
- Run server by running `npm run dev`
## Production
- Install all required libraries by running `npm install`
- Run server by running `npm start`