USAGE
```
node server.js


cd client
npm run start
```